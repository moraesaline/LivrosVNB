import Header from './components/Header/header'
import Footer from './components/Footer/footer'
import './GlobalStyle/globalstyle.module.scss'



export default function App(){
  return(
    <>
    <Header/>
    <Footer/>
    </>
  )
}